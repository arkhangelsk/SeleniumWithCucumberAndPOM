package com.testerstories.tutorial.todos.pages;

import java.util.List;
import java.util.function.IntPredicate;
import java.util.stream.Collectors;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.core.pages.WebElementFacade;
import net.thucydides.core.annotations.DefaultUrl;
//import net.thucydides.core.annotations.DefaultUrl;
import net.thucydides.core.annotations.Managed;

@DefaultUrl("http://todomvc.com/examples/angularjs")
public class TodoPage extends PageObject{
	
	
//	public void openBrowser(){
//		System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
//		WebDriver driver = new ChromeDriver();
//	
//		driver.get("http://www.google.com"); 
//		driver.findElement(By.name("q")).sendKeys("firefly", Keys.ENTER);
//	}
	
	public void addActionCalled(String actionName) {
        WebElement todoField = getDriver().findElement(By.cssSelector("#new-todo"));
        todoField.sendKeys(actionName);
        todoField.sendKeys(Keys.ENTER);
    }

	/**
	 * Here findAll(), defined on a PageObject, takes in a By instance which should be a selector. 
	 * The rest of this is basically a functional representation of a map-reduce operation, finding all elements on the page that match the selector “.view”. 
	 * then streaming that collection and mapping to the getText() method of the WebElementFacade. 
	 * Behind the scenes this handles using a Selenium WebElement and calling a method on getting the text. 
	 * The collect() method is then used on the stream to get each item collected and create a list of string from that collection.
	 * @return
	 */
	public List<String> getActions() {
		
        return findAll(".view").stream()
                .map(WebElementFacade::getText)
                .collect(Collectors.toList());
    }
	
}
