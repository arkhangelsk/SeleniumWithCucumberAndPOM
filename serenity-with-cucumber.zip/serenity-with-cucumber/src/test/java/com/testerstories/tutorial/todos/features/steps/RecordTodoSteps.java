package com.testerstories.tutorial.todos.features.steps;

import com.testerstories.tutorial.todos.pages.TodoPage;
import static org.assertj.core.api.Assertions.assertThat;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RecordTodoSteps {
	TodoPage todoPage;

	@Given("^the todo application$")
	public void start_the_todo_application() {
		todoPage.open();
	//	todoPage.openBrowser();
		System.out.println("Inside Given Section ");
	}
	
	@When("^the todo action '(.*)' is added$")
    public void add_a_todo_action(String actionName) {
		System.out.println("Inside When Section ");
		todoPage.addActionCalled(actionName);
    }
	
	@Then("^'(.*)' should appear in the todo list$")
    public void action_should_appear_in_my_todo_list(String action) {
        assertThat(todoPage.getActions()).contains(action);
    }
}
