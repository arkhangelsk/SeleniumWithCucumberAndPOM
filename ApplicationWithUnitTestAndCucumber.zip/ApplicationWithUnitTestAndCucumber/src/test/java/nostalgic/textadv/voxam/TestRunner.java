package nostalgic.textadv.voxam;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.*;
 
@RunWith(Cucumber.class)
@CucumberOptions(
		    features = "src/Features",
			plugin = {"pretty",
			"html:target/test-report/cucumber_sanity",
			"json:target/test-report/test-report.json",
			"junit:target/test-report/test-report.xml"})
public class TestRunner {
	
}