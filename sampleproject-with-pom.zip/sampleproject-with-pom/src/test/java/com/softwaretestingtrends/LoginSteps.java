package com.softwaretestingtrends;

import static org.junit.Assert.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.softwaretestingtrends.pages.LoginPage;
import com.softwaretestingtrends.pages.SecureLandingPage;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
 
public class LoginSteps {
	
  WebDriver driver;
  LoginPage login;
  SecureLandingPage securepage;
	
  @Given("^The Internet Home Page$")
  public void the_Internet_Home_Page() throws Throwable {
	  login = new LoginPage(driver);
	  login.navigateTo();
	}
  
 
  @When("^logging in as a user$")
  public void logging_in_as_a_user() throws Throwable {
	  login.loginAsUser();
  }
 
  @Then("^user logged into secure area$")
  public void the_secure_page_message_is_displayed() throws Throwable {
	  securepage = new SecureLandingPage(driver);
	  securepage.checkForDisplayedMessage();  }
  
  @Before
  public void startUp() {
	System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
    driver = new ChromeDriver();
  }
 
  @After
  public void tearDown() {
    driver.quit();
  }
}