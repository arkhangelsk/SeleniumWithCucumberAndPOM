package com.softwaretestingtrends.pages;

import static org.junit.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

public class BasePage {
	protected WebDriver driver;	//Here “protected” means any page inheriting from this page gets access to the driver variable. 
	
	public BasePage(WebDriver driver) {
	    this.driver = driver;
	  }
	
	public LoginPage navigateTo() {
		driver.get("https://the-internet.herokuapp.com/login");
	    assertEquals("The Internet", driver.getTitle());
	    return new LoginPage(driver);
	  }
}
