package com.softwaretestingtrends.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage extends BasePage {
	
	private final By usernameSelector 	= By.id("username");
	private final By passwordSelector 	= By.id("password");
	private final By loginSelector 		= By.className("fa-sign-in");

	public LoginPage(WebDriver driver) {
		super(driver);
	}

	public LoginPage loginAsUser() {
		
		WebElement username = driver.findElement(usernameSelector);
		WebElement password = driver.findElement(passwordSelector);
		WebElement login = driver.findElement(loginSelector);
		
		username.sendKeys("tomsmith");
		password.sendKeys("SuperSecretPassword!");
		login.click();
		
		return new LoginPage(driver);
	  }
}
