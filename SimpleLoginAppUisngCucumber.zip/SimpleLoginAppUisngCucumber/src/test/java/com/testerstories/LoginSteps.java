package com.testerstories;

import static org.junit.Assert.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
 
public class LoginSteps {
	
  WebDriver driver;
	
  @Given("^The Internet Home Page$")
  public void the_Internet_Home_Page() throws Throwable {
	    driver.get("https://the-internet.herokuapp.com/login");
	    assertEquals("The Internet", driver.getTitle());
	}
  
 
  @When("^logging in as a user$")
  public void logging_in_as_a_user() throws Throwable {

      WebElement username = driver.findElement(By.id("username"));
      username.sendKeys("tomsmith");
 
      WebElement password = driver.findElement(By.id("password"));
      password.sendKeys("SuperSecretPassword!");
 
      WebElement login = driver.findElement(By.className("fa-sign-in"));
 
      login.click();
  }
 
  @Then("^user logged into secure area$")
  public void the_home_page_navigation_is_available() throws Throwable {
	  WebElement messageSecureArea = (new WebDriverWait(driver, 20))
		      .until(ExpectedConditions.visibilityOfElementLocated(By.className("subheader")));
  String sMessageDisplayed =  messageSecureArea.getText();
  System.out.println("Message Displayed: " + sMessageDisplayed);
  assertEquals("Welcome to the Secure Area. When you are done click logout below.", sMessageDisplayed);
  }
  
  @Before
  public void startUp() {
	System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver_win32\\chromedriver.exe");
    driver = new ChromeDriver();
  }
 
  @After
  public void tearDown() {
    driver.quit();
  }
}